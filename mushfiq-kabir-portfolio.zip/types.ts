export interface Project {
  id: string;
  title: string;
  tags: string;
  shortDescription: string;
  heroImage: string;
  thumbnail: string;
  role: string;
  year: string;
  deliverables: string;
  heading: string;
  description: string;
  challenge: string;
  solution: string;
  stack: string[];
  results: string[];
  detailImage: string;
}

export interface NavigationItem {
  label: string;
  href: string;
}