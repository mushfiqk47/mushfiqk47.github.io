import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { projectsData } from '../data';
import Section from '../components/Section';

export default function ProjectDetail() {
  const { id } = useParams<{ id: string }>();
  const project = projectsData.find(p => p.id === id);
  const currentIndex = projectsData.findIndex(p => p.id === id);

  if (!project) {
    return <Navigate to="/projects" replace />;
  }

  const prevProject = projectsData[currentIndex - 1] || projectsData[projectsData.length - 1];
  const nextProject = projectsData[currentIndex + 1] || projectsData[0];

  return (
    <div className="w-full pt-[80px]">
      <div className="h-[50vh] md:h-[60vh] w-full overflow-hidden border-b-[10px] border-solar-flare relative">
        <img src={project.heroImage} alt={project.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/30"></div>
      </div>

      <Section className="!pt-12 md:!pt-24">
        <div className="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-12 lg:gap-32">
            
            {/* Sidebar */}
            <aside className="lg:sticky lg:top-32 h-fit">
                <h1 className="text-5xl md:text-6xl font-bold uppercase text-felt-base mb-12 leading-none">
                    {project.title}
                </h1>
                
                <div className="flex flex-col gap-8 mb-12">
                    {[
                        { label: 'ROLE', val: project.role },
                        { label: 'YEAR', val: project.year },
                        { label: 'DELIVERABLES', val: project.deliverables }
                    ].map(meta => (
                        <div key={meta.label}>
                            <dt className="font-mono text-xs text-solar-amber mb-1">{meta.label}</dt>
                            <dd className="text-xl font-bold text-felt-base">{meta.val}</dd>
                        </div>
                    ))}
                </div>

                <div className="mb-12">
                    <span className="font-mono text-xs text-solar-amber mb-4 block">TECH STACK</span>
                    <div className="flex flex-wrap gap-2">
                        {project.stack.map(tech => (
                            <span key={tech} className="font-mono text-xs px-3 py-1 border border-white/20 bg-white/5 uppercase text-felt-base">
                                {tech}
                            </span>
                        ))}
                    </div>
                </div>

                <Link 
                    to="/contact" 
                    className="inline-block w-full text-center bg-solar-flare text-brutal-black px-8 py-4 font-bold uppercase border-2 border-brutal-black shadow-brutal hover:bg-solar-amber hover:-translate-y-1 transition-all"
                >
                    Work with me
                </Link>
            </aside>

            {/* Content */}
            <article>
                <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                    Overview
                </span>
                <h2 className="text-3xl md:text-5xl font-bold uppercase text-felt-base mb-8 leading-tight">
                    {project.heading}
                </h2>
                <p className="text-xl text-felt-base/80 leading-relaxed mb-16 max-w-2xl">
                    {project.description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
                    <div className="bg-felt-base p-8 border-[4px] border-brutal-black text-brutal-black shadow-brutal">
                        <span className="font-mono text-xs font-bold uppercase text-solar-flare mb-4 block">The Challenge</span>
                        <p className="leading-relaxed">{project.challenge}</p>
                    </div>
                    <div className="bg-felt-base p-8 border-[4px] border-brutal-black text-brutal-black shadow-brutal">
                        <span className="font-mono text-xs font-bold uppercase text-solar-flare mb-4 block">The Solution</span>
                        <p className="leading-relaxed">{project.solution}</p>
                    </div>
                </div>

                <div className="mb-20 border-[4px] border-felt-base overflow-hidden">
                    <img src={project.detailImage} alt="Details" className="w-full" />
                </div>

                <div className="bg-solar-flare p-10 md:p-16 border-[4px] border-brutal-black shadow-brutal-solar mb-24 text-brutal-black">
                     <span className="font-mono text-xs tracking-widest text-solar-amber bg-brutal-black px-3 py-1.5 border-2 border-solar-amber mb-8 inline-block">
                        KEY RESULTS
                    </span>
                    <ul className="space-y-6">
                        {project.results.map((res, i) => (
                            <li key={i} className="text-xl md:text-2xl font-bold flex gap-4">
                                <span>—</span> {res}
                            </li>
                        ))}
                    </ul>
                </div>

                <nav className="flex flex-col md:flex-row justify-between gap-6 p-8 bg-brutal-black border-2 border-solar-flare">
                    <Link to={`/project/${prevProject.id}`} className="text-felt-base font-mono uppercase text-sm hover:text-solar-amber transition-colors flex items-center gap-4 group">
                        <span className="group-hover:-translate-x-2 transition-transform">←</span> {prevProject.title}
                    </Link>
                    <Link to={`/project/${nextProject.id}`} className="text-felt-base font-mono uppercase text-sm hover:text-solar-amber transition-colors flex items-center gap-4 group text-right">
                        {nextProject.title} <span className="group-hover:translate-x-2 transition-transform">→</span>
                    </Link>
                </nav>
            </article>
        </div>
      </Section>
    </div>
  );
}