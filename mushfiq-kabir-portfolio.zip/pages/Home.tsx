import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Figma, Layers, Image, PenTool } from 'lucide-react';
import Section from '../components/Section';
import ProjectCard from '../components/ProjectCard';
import { projectsData } from '../data';

export default function Home() {
    const location = useLocation();

    useEffect(() => {
        if (location.hash) {
            const elem = document.querySelector(location.hash);
            if (elem) {
                elem.scrollIntoView({ behavior: 'smooth' });
            }
        }
    }, [location]);

  return (
    <div className="w-full">
      {/* HERO */}
      <section className="min-h-[95vh] pt-[80px] grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-32 items-center px-6 md:px-8 max-w-[1400px] mx-auto">
        <div className="flex flex-col items-start justify-center animate-fade-in-up">
            <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6">
                GRAPHIC & UI/UX DESIGNER
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-bold uppercase leading-[0.95] mb-8 text-felt-base">
                Designing clarity<br/>from complexity.
            </h1>
            <p className="text-xl text-felt-base/85 leading-relaxed max-w-lg mb-12">
                Md. Mushfiq Kabir is a multidisciplinary designer and CS undergraduate. Merging systemic logic with visual precision to build intuitive digital products.
            </p>
            <Link 
                to="/contact" 
                className="inline-block bg-solar-flare text-brutal-black px-10 py-5 font-grotesk font-bold text-lg uppercase border-[4px] border-brutal-black shadow-brutal hover:shadow-brutal-hover hover:-translate-x-1 hover:-translate-y-1 hover:bg-solar-amber transition-all duration-300"
            >
                Contact for Project
            </Link>
        </div>

        <div className="relative order-first lg:order-last mx-auto lg:mx-0 w-full max-w-[500px] aspect-[4/5] bg-brutal-black border-[4px] border-brutal-black shadow-brutal-solar hover:shadow-brutal hover:scale-[1.02] transition-all duration-500 overflow-hidden group">
            <img 
                src="https://picsum.photos/600/800" 
                alt="Mushfiq Kabir" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
            />
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-t from-black/50 to-transparent"></div>
            <div className="absolute bottom-8 right-[-1rem] bg-solar-amber text-brutal-black px-6 py-3 font-mono font-bold text-xs border-[3px] border-brutal-black shadow-brutal-sm animate-badge-float z-10">
                AVAILABLE FOR WORK
            </div>
        </div>
      </section>

      {/* ABOUT / BENTO */}
      <Section id="about">
        <div className="mb-20">
            <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                Core Registry
            </span>
            <h2 className="text-4xl md:text-6xl font-bold uppercase text-felt-base">About Me</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-[minmax(180px,auto)]">
            {/* Experience */}
            <div className="col-span-1 md:col-span-2 row-span-2 bg-felt-base border-[4px] border-brutal-black p-8 text-brutal-black flex flex-col justify-between shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1.5 transition-all duration-300 group">
                <span className="font-mono text-xs tracking-widest bg-solar-amber px-2 py-1 w-fit border border-brutal-black">PROFESSIONAL EXPERIENCE</span>
                <div className="mt-6 space-y-8">
                    <div className="pl-6 border-l-2 border-solar-flare">
                        <h3 className="text-xl font-bold">UI/UX Designer</h3>
                        <span className="font-mono text-sm text-solar-flare block mb-2">Creative IT Institute | 2024</span>
                        <p className="opacity-80 text-sm">Developed interactive prototypes and design systems. Validated user flows through rapid iteration.</p>
                    </div>
                    <div className="pl-6 border-l-2 border-white/20 group-hover:border-white/40 transition-colors">
                        <h3 className="text-xl font-bold">Freelance Designer</h3>
                        <span className="font-mono text-sm text-solar-flare block mb-2">Upwork & Direct | 2023 - Present</span>
                        <p className="opacity-80 text-sm">Delivering brand identity and web design solutions for international clients.</p>
                    </div>
                </div>
            </div>

            {/* Tools */}
            <div className="col-span-1 md:col-span-2 bg-felt-base border-[4px] border-brutal-black p-8 text-brutal-black flex flex-col shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1.5 transition-all duration-300">
                <span className="font-mono text-xs tracking-widest bg-solar-amber px-2 py-1 w-fit border border-brutal-black mb-6">TECH STACK</span>
                <div className="grid grid-cols-2 gap-4">
                     {[
                        { icon: Figma, name: 'Figma' },
                        { icon: Layers, name: 'Adobe XD' },
                        { icon: Image, name: 'Photoshop' },
                        { icon: PenTool, name: 'Illustrator' }
                     ].map((Tool, i) => (
                        <div key={i} className="flex items-center gap-3 p-3 border border-brutal-black/10 bg-white/50 hover:bg-solar-flare/10 hover:border-solar-flare transition-all">
                            <Tool.icon size={20} className="text-solar-flare" />
                            <span className="font-mono text-sm font-bold uppercase">{Tool.name}</span>
                        </div>
                     ))}
                </div>
            </div>

            {/* Education */}
            <div className="col-span-1 bg-felt-base border-[4px] border-brutal-black p-6 text-brutal-black flex flex-col justify-between shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1.5 transition-all duration-300">
                 <span className="font-mono text-xs tracking-widest bg-solar-amber px-2 py-1 w-fit border border-brutal-black">EDUCATION</span>
                 <div className="mt-auto">
                    <div className="text-4xl font-bold text-solar-flare leading-none mb-2">B.Sc.</div>
                    <div className="font-mono text-sm opacity-80">Computer Science</div>
                    <div className="font-mono text-xs opacity-60 mt-2">Northern Univ, 2025+</div>
                 </div>
            </div>

            {/* Cert */}
            <div className="col-span-1 bg-felt-base border-[4px] border-brutal-black p-6 text-brutal-black flex flex-col justify-between shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1.5 transition-all duration-300">
                 <span className="font-mono text-xs tracking-widest bg-solar-amber px-2 py-1 w-fit border border-brutal-black">CERTIFICATION</span>
                 <div className="mt-auto">
                    <div className="text-4xl font-bold text-solar-flare leading-none mb-2">UI/UX</div>
                    <div className="font-mono text-sm opacity-80">Professional Cert.</div>
                    <div className="font-mono text-xs opacity-60 mt-2">Creative IT Inst., 2024</div>
                 </div>
            </div>
            
            {/* Skills */}
            <div className="col-span-1 md:col-span-4 bg-felt-base border-[4px] border-brutal-black p-8 text-brutal-black shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1.5 transition-all duration-300">
                <div className="flex flex-wrap md:flex-nowrap gap-8 items-center justify-between">
                    <div>
                         <span className="font-mono text-xs tracking-widest bg-solar-amber px-2 py-1 w-fit border border-brutal-black block mb-2">CORE COMPETENCIES</span>
                         <h3 className="text-2xl font-bold uppercase">Bridging Design & Logic</h3>
                    </div>
                    <div className="flex flex-wrap gap-3">
                        {['Design Systems', 'Wireframing', 'Interaction Design', 'User Research', 'Prototyping', 'Design Principle'].map(skill => (
                            <span key={skill} className="font-mono text-xs px-3 py-1.5 border border-brutal-black bg-black/5 uppercase">
                                {skill}
                            </span>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      </Section>

      {/* EXPERTISE */}
      <Section id="expertise">
         <div className="mb-20">
            <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                Expertise
            </span>
            <h2 className="text-4xl md:text-6xl font-bold uppercase text-felt-base leading-tight">Specialized in<br/>digital experiences.</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
                { 
                    id: '01', 
                    title: 'UI/UX Design', 
                    desc: 'Translating user needs into interactive prototypes. Focusing on clear navigation and design problem-solving.', 
                    tags: ['Figma', 'Prototyping'] 
                },
                { 
                    id: '02', 
                    title: 'Visual Communication', 
                    desc: 'Crafting distinct brand identities. Using color theory and typography to communicate hierarchy and intent.', 
                    tags: ['Photoshop', 'Illustrator'] 
                },
                { 
                    id: '03', 
                    title: 'Interaction Design', 
                    desc: 'Creating dynamic, responsive interfaces that feel alive. Bridging the gap between static visuals and experience.', 
                    tags: ['Prototyping', 'Animation'] 
                },
            ].map(item => (
                <div key={item.id} className="bg-felt-base p-10 border-[4px] border-brutal-black shadow-brutal hover:shadow-brutal-solar hover:-translate-y-2 transition-all duration-300 text-brutal-black flex flex-col">
                    <div className="font-mono text-3xl mb-8 text-solar-flare">{item.id}</div>
                    <h3 className="text-2xl font-bold uppercase mb-4">{item.title}</h3>
                    <p className="text-sm leading-relaxed mb-8 opacity-90">{item.desc}</p>
                    <div className="mt-auto flex flex-wrap gap-2">
                        {item.tags.map(tag => (
                            <span key={tag} className="font-mono text-xs px-2 py-1 border border-brutal-black/20 bg-white/50">{tag}</span>
                        ))}
                    </div>
                </div>
            ))}
        </div>
      </Section>

      {/* FEATURED WORK */}
      <Section id="work">
        <div className="flex flex-wrap justify-between items-end mb-20 gap-8">
            <div>
                 <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                    PORTFOLIO
                </span>
                <h2 className="text-4xl md:text-6xl font-bold uppercase text-felt-base">Featured Projects</h2>
                <p className="mt-6 max-w-lg text-felt-base/80 text-lg">
                    A curation of digital products and visual experiments combining logic and aesthetics.
                </p>
            </div>
            <Link to="/projects" className="bg-solar-flare text-brutal-black px-8 py-4 font-bold uppercase border-2 border-brutal-black shadow-brutal hover:shadow-brutal-hover hover:-translate-y-1 transition-all">
                See All Work →
            </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {projectsData.slice(0, 2).map((project, index) => (
                <ProjectCard key={project.id} project={project} index={index} />
            ))}
        </div>
      </Section>

      {/* PROCESS */}
      <Section id="process">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-3 lg:col-span-1 mb-8 lg:mb-0">
                 <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                    OPERATIONAL PROTOCOL
                </span>
                <h2 className="text-5xl font-bold uppercase text-felt-base mb-6">From Concept<br/>to Code.</h2>
                 <p className="text-felt-base/80 text-lg mb-8 max-w-md">
                    A disciplined workflow designed to bridge the gap between abstract requirements and functional reality.
                </p>
                 <Link to="/contact" className="inline-block bg-solar-flare text-brutal-black px-8 py-4 font-bold uppercase border-2 border-brutal-black shadow-brutal hover:bg-solar-amber transition-all">
                    Contact me
                </Link>
            </div>
            <div className="md:col-span-3 lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {[
                    { id: '01', title: 'Discovery', text: 'Deconstructing requirements to align goals with user needs.' },
                    { id: '02', title: 'Architecture', text: 'Mapping user flows and info hierarchy for logical navigation.' },
                    { id: '03', title: 'Prototyping', text: 'Rapidly visualizing concepts to validate interactions.' },
                    { id: '04', title: 'Systems', text: 'Building atomic component libraries for scalability.' },
                    { id: '05', title: 'Implement', text: 'Translating design specs into clean, semantic code.' },
                    { id: '06', title: 'Delivery', text: 'Finalizing assets, documentation, and QA for launch.' },
                ].map(step => (
                    <div key={step.id} className="bg-felt-base p-6 border-[3px] border-brutal-black text-brutal-black flex flex-col shadow-brutal hover:shadow-brutal-solar hover:-translate-y-1 transition-all">
                        <div className="font-mono text-2xl mb-4 text-solar-flare">{step.id}</div>
                        <h3 className="text-lg font-bold uppercase mb-2">{step.title}</h3>
                        <p className="text-sm opacity-80">{step.text}</p>
                    </div>
                ))}
            </div>
        </div>
      </Section>
    </div>
  );
}