import React from 'react';
import Section from '../components/Section';
import ProjectCard from '../components/ProjectCard';
import { projectsData } from '../data';

export default function Projects() {
  return (
    <div className="pt-[100px] w-full min-h-screen">
      <Section>
        <div className="mb-20">
             <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-6 inline-block">
                PORTFOLIO
            </span>
            <h2 className="text-4xl md:text-6xl font-bold uppercase text-felt-base">All Projects</h2>
        </div>
        <div className="grid grid-cols-1 gap-24 max-w-5xl mx-auto">
            {projectsData.map((project, index) => (
                <ProjectCard key={project.id} project={project} index={index} />
            ))}
        </div>
      </Section>
    </div>
  );
}