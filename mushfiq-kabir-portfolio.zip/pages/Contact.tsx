import React, { useState } from 'react';
import Section from '../components/Section';

export default function Contact() {
  const [copied, setCopied] = useState(false);
  const email = "mushfiqk47@gmail.com";

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(email);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      window.location.href = `mailto:${email}`;
    }
  };

  return (
    <div className="pt-[100px] min-h-screen w-full">
      <Section className="flex flex-col justify-center min-h-[70vh]">
        <div className="grid grid-cols-1 lg:grid-cols-[1.5fr_1fr] gap-16 lg:gap-32 items-start">
          
          {/* Primary */}
          <div className="flex flex-col">
             <span className="font-mono text-sm tracking-widest text-brutal-black bg-solar-amber px-3 py-1.5 border-2 border-brutal-black mb-8 w-fit">
                INITIATE PROTOCOL
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-[5.5rem] font-bold uppercase leading-none text-felt-base mb-12">
                Have an idea?<br/>Let's build it.
            </h1>

            <div className="relative w-fit mb-12">
                <button 
                    onClick={handleCopy}
                    className={`
                        flex items-center gap-4 bg-transparent border-[3px] px-8 py-5 text-xl md:text-3xl font-grotesk font-bold transition-all duration-300
                        ${copied ? 'border-green-400 text-green-400' : 'border-solar-flare text-felt-base hover:bg-solar-flare/10 hover:-translate-y-1'}
                    `}
                    aria-label="Copy email"
                >
                    {email}
                    <span className="text-2xl" aria-hidden="true">{copied ? '✓' : '📋'}</span>
                </button>
                <div className={`absolute -bottom-8 left-0 font-mono text-sm text-green-400 transition-all duration-300 ${copied ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}>
                    Copied to clipboard!
                </div>
            </div>

            <div className="inline-flex items-center gap-4 px-6 py-3 bg-white/5 border border-white/10 rounded w-fit">
                <span className="w-3 h-3 bg-green-400 rounded-full shadow-[0_0_10px_#4ade80] animate-pulse"></span>
                <span className="font-mono text-sm text-felt-base tracking-wider">AVAILABLE FOR NEW VENTURES — Q1 2026</span>
            </div>
          </div>

          {/* Secondary Info */}
          <div className="flex flex-col gap-12 pt-4">
            <div className="border-l-[3px] border-solar-flare pl-6">
                <span className="font-mono text-xs text-solar-amber mb-2 block">HQ COORDINATES</span>
                <p className="text-xl md:text-2xl text-felt-base font-mono leading-relaxed">
                    Uttara, Dhaka<br/>Bangladesh
                </p>
            </div>
            
            <div className="border-l-[3px] border-solar-flare pl-6">
                <span className="font-mono text-xs text-solar-amber mb-2 block">DIRECT LINE</span>
                <p className="text-xl md:text-2xl text-felt-base font-mono">
                    +880 1635 309469
                </p>
            </div>

            <div className="border-l-[3px] border-solar-flare pl-6">
                <span className="font-mono text-xs text-solar-amber mb-4 block">NETWORK</span>
                <div className="grid grid-cols-2 gap-4">
                    {['Behance', 'LinkedIn', 'GitHub', 'Upwork'].map(net => (
                        <a 
                            key={net} 
                            href="#" 
                            className="flex items-center justify-between p-4 bg-white/5 border border-white/10 text-felt-base font-mono text-sm hover:bg-solar-flare hover:text-brutal-black hover:border-solar-flare hover:translate-x-1 transition-all"
                        >
                            {net} <span>↗</span>
                        </a>
                    ))}
                </div>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
}