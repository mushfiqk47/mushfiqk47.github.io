import React from 'react';
import { NavLink } from 'react-router-dom';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
  index: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, index }) => {
  return (
    <NavLink 
      to={`/project/${project.id}`}
      className="group relative bg-brutal-black border border-white/10 flex flex-col h-full overflow-hidden transition-all duration-400 hover:-translate-y-1.5 hover:shadow-brutal-solar z-10"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-brutal-black w-full">
        <img 
          src={project.thumbnail} 
          alt={project.title} 
          className="w-full h-full object-cover transition-all duration-700 ease-[cubic-bezier(0.23,1,0.32,1)] grayscale group-hover:grayscale-0 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <span className="bg-solar-flare text-brutal-black font-mono font-bold uppercase text-sm px-6 py-3 translate-y-5 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 delay-75">
                View Case Study
            </span>
        </div>
      </div>

      <div className="flex flex-col flex-grow justify-between p-6 bg-brutal-black border-t-2 border-solar-flare relative z-20">
        <div className="mb-6">
            <div className="flex justify-between items-start mb-4">
                <h3 className="text-2xl font-bold uppercase text-felt-base group-hover:text-solar-amber transition-colors leading-none">
                    {project.title}
                </h3>
                <span className="font-mono text-xs text-white/40 border border-white/10 px-2 py-1 rounded">
                    0{index + 1}
                </span>
            </div>
            <p className="text-felt-base/60 text-sm leading-relaxed">
                {project.shortDescription}
            </p>
        </div>
        <div className="flex flex-wrap gap-2">
            {project.tags.split('/').map((tag, i) => (
                <span key={i} className="font-mono text-[10px] uppercase text-brutal-black bg-felt-base px-2 py-1">
                    {tag.trim()}
                </span>
            ))}
        </div>
      </div>
    </NavLink>
  );
};

export default ProjectCard;