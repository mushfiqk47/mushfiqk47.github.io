import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
    document.body.style.overflow = !isOpen ? 'hidden' : '';
  };

  const closeMenu = () => {
    setIsOpen(false);
    document.body.style.overflow = '';
  };

  return (
    <>
      <nav
        className={`fixed top-0 w-full z-50 transition-all duration-300 flex justify-between items-center px-[5%] h-[80px]
        ${scrolled ? 'bg-brutal-black/95 border-b-2 border-solar-flare h-[70px]' : 'bg-brutal-black/85 backdrop-blur-md border-b-2 border-white/5'}
        `}
      >
        <NavLink to="/" className="flex items-center gap-3 text-decoration-none group" onClick={closeMenu}>
           {/* SVG Logo Placeholder */}
            <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="block">
                <rect width="40" height="40" fill="#FF4D00"/>
                <path d="M10 10V30H15V15H20V30H25V10H10Z" fill="#121212"/>
            </svg>
            <span className="font-bold text-xl tracking-[0.2em] bg-gradient-to-r from-felt-base to-solar-amber bg-clip-text text-transparent uppercase group-hover:to-solar-flare transition-all">
                Mushfiq Kabir
            </span>
        </NavLink>

        <div className="hidden md:flex gap-12">
            {[
                { name: 'Home', path: '/' },
                { name: 'Projects', path: '/projects' },
                { name: 'About', path: '/#about' },
                { name: 'Contact', path: '/contact' }
            ].map((link) => (
                <NavLink 
                    key={link.name} 
                    to={link.path}
                    className={({ isActive }) => `
                        font-mono text-sm tracking-widest uppercase relative py-2 transition-colors duration-300
                        ${isActive && link.path !== '/#about' ? 'text-solar-amber after:w-full' : 'text-felt-base hover:text-solar-amber'}
                        after:content-[''] after:absolute after:bottom-0 after:left-0 after:h-[2px] after:bg-solar-flare after:transition-all after:duration-300 after:w-0 hover:after:w-full
                    `}
                >
                    {link.name}
                </NavLink>
            ))}
        </div>

        <div className="hidden md:block">
            <a 
                href="/assets/pdf/Mushfiq-CV.pdf" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-solar-flare text-brutal-black px-6 py-3 font-mono font-bold text-xs uppercase border-2 border-brutal-black tracking-wider hover:bg-solar-amber hover:shadow-brutal-sm hover:-translate-y-0.5 transition-all duration-300"
            >
                Download CV
            </a>
        </div>

        <button 
            className="md:hidden text-felt-base z-[2001] p-2"
            onClick={toggleMenu}
            aria-label="Toggle Menu"
        >
            {isOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </nav>

      {/* Mobile Menu Overlay */}
      <div 
        className={`fixed inset-0 bg-brutal-black z-[1500] flex flex-col justify-center items-center transition-transform duration-500 ease-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="flex flex-col gap-10 text-center w-full">
             {[
                { name: 'Home', path: '/' },
                { name: 'Projects', path: '/projects' },
                { name: 'About', path: '/#about' },
                { name: 'Contact', path: '/contact' }
            ].map((link, idx) => (
                <NavLink 
                    key={link.name} 
                    to={link.path}
                    onClick={closeMenu}
                    className="text-felt-base font-grotesk text-4xl font-bold uppercase hover:text-solar-amber transition-colors"
                    style={{ transitionDelay: `${idx * 100}ms` }}
                >
                    {link.name}
                </NavLink>
            ))}
            <a 
                href="/assets/pdf/Mushfiq-CV.pdf" 
                target="_blank" 
                rel="noopener noreferrer"
                className="mx-auto mt-8 bg-solar-flare text-white px-8 py-4 font-bold uppercase text-lg border-none hover:bg-solar-amber transition-all"
            >
                Download CV
            </a>
        </div>
      </div>
    </>
  );
}