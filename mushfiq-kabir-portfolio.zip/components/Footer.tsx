import React from 'react';
import { NavLink } from 'react-router-dom';

const SocialLink = ({ href, label }: { href: string; label: string }) => (
  <div className="clip-link-box relative border border-white/10 overflow-hidden group">
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="block p-4 text-felt-base font-mono text-sm relative z-10 hover:text-brutal-black transition-colors duration-300"
    >
      {label} ↗
    </a>
    <div className="clip-link-overlay absolute inset-0 bg-solar-flare z-0" aria-hidden="true" />
  </div>
);

export default function Footer() {
  return (
    <footer className="bg-brutal-black pt-32 pb-16 border-t-[10px] border-solar-flare px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-[1.5fr_2fr] gap-24 mb-16">
        <div className="flex flex-col gap-6">
            <NavLink to="/" className="flex items-center gap-3">
                <svg width="32" height="32" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="block">
                    <rect width="40" height="40" fill="#FF4D00"/>
                    <path d="M10 10V30H15V15H20V30H25V10H10Z" fill="#121212"/>
                </svg>
                <span className="font-bold text-xl tracking-[0.2em] bg-gradient-to-r from-felt-base to-solar-amber bg-clip-text text-transparent uppercase">
                    Mushfiq Kabir
                </span>
            </NavLink>
          <p className="text-felt-base/70 leading-relaxed max-w-sm font-grotesk">
            Digital architect & designer building legacy systems through user-centric logic and premium aesthetics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          <div className="flex flex-col gap-5">
            <span className="font-mono text-sm tracking-widest text-solar-amber uppercase border-2 border-brutal-black bg-brutal-black w-fit px-3 py-1 mb-2">Explore</span>
            <NavLink to="/" className="text-felt-base font-mono text-sm hover:text-solar-amber w-fit transition-colors">Home Registry</NavLink>
            <NavLink to="/projects" className="text-felt-base font-mono text-sm hover:text-solar-amber w-fit transition-colors">All Projects</NavLink>
            <NavLink to="/#about" className="text-felt-base font-mono text-sm hover:text-solar-amber w-fit transition-colors">Core Registry</NavLink>
            <NavLink to="/contact" className="text-felt-base font-mono text-sm hover:text-solar-amber w-fit transition-colors">Contact Lab</NavLink>
          </div>

          <div className="flex flex-col gap-2">
             <span className="font-mono text-sm tracking-widest text-solar-amber uppercase border-2 border-brutal-black bg-brutal-black w-fit px-3 py-1 mb-6">Connect</span>
             <SocialLink href="https://behance.net/" label="Behance" />
             <SocialLink href="https://linkedin.com/" label="LinkedIn" />
             <SocialLink href="https://github.com/" label="GitHub" />
             <SocialLink href="mailto:mushfiqk47@gmail.com" label="Email" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-felt-base/50 font-mono text-xs uppercase">
        <span>Dhaka, Bangladesh</span>
        <span>© 2026 Designed & Built by Mushfiq Kabir</span>
      </div>
    </footer>
  );
}